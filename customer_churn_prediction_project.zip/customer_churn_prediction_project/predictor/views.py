import os, json, uuid
import pandas as pd
from django.conf import settings
from django.shortcuts import render
from django.contrib import messages
from django.views.decorators.http import require_POST
from .services import load_frame, run_analysis, predict_one

def index(request):
    context = {"has_model": False}
    if request.method == "POST" and request.FILES.get("dataset"):
        uploaded = request.FILES["dataset"]
        run_id = uuid.uuid4().hex
        out_dir = os.path.join(settings.MEDIA_ROOT, "runs", run_id)
        try:
            raw = load_frame(uploaded)
            cleaned, summary, metrics = run_analysis(raw, out_dir)
            request.session["active_run"] = run_id
            request.session["upload_name"] = uploaded.name
            context.update({
                "has_model": True, "summary": summary, "metrics": metrics,
                "preview": cleaned.head(10).to_html(classes="table table-sm table-striped", index=False, border=0),
                "run_id": run_id,
                "chart_names": [n for n in [
                    "churn_distribution.png", "numeric_distribution.png", "boxplot.png",
                    "scatterplot.png", "correlation_heatmap.png", "category_churn.png",
                    "feature_importance.png"
                ] if os.path.exists(os.path.join(out_dir, n))],
                "upload_name": uploaded.name,
                "feature_form": build_feature_form(cleaned, summary["target"]),
            })
        except Exception as exc:
            messages.error(request, str(exc))
    elif request.session.get("active_run"):
        run_id = request.session["active_run"]
        out_dir = os.path.join(settings.MEDIA_ROOT, "runs", run_id)
        try:
            with open(os.path.join(out_dir, "summary.json")) as f: summary = json.load(f)
            with open(os.path.join(out_dir, "metrics.json")) as f: metrics = json.load(f)
            preview = pd.read_csv(os.path.join(out_dir, "preview.csv"))
            model = __import__("joblib").load(os.path.join(out_dir, "churn_model.joblib"))
            original = pd.read_csv(os.path.join(out_dir, "preview.csv"))
            context.update({
                "has_model": True, "summary": summary, "metrics": metrics,
                "preview": preview.to_html(classes="table table-sm table-striped", index=False, border=0),
                "run_id": run_id, "upload_name": request.session.get("upload_name", "Dataset"),
                "chart_names": [n for n in [
                    "churn_distribution.png", "numeric_distribution.png", "boxplot.png",
                    "scatterplot.png", "correlation_heatmap.png", "category_churn.png",
                    "feature_importance.png"
                ] if os.path.exists(os.path.join(out_dir, n))],
                "feature_form": build_feature_form_from_bundle(model),
            })
        except Exception:
            pass
    return render(request, "predictor/index.html", context)

def build_feature_form(df, target):
    fields = []
    for col in df.drop(columns=[target]).columns:
        if pd.api.types.is_numeric_dtype(df[col]):
            median = df[col].median()
            fields.append({"name": col, "numeric": True, "value": "" if pd.isna(median) else round(float(median), 2)})
        else:
            vals = df[col].dropna().astype(str).value_counts().index.tolist()
            fields.append({"name": col, "numeric": False, "choices": vals[:30], "value": vals[0] if vals else ""})
    return fields

def build_feature_form_from_bundle(bundle):
    # Build choices from the training preview where possible; unseen categories are accepted by the encoder.
    fields = []
    for col in bundle["feature_columns"]:
        if col in bundle["numeric_cols"]:
            fields.append({"name": col, "numeric": True, "value": ""})
        else:
            fields.append({"name": col, "numeric": False, "choices": [], "value": ""})
    return fields

@require_POST
def predict(request):
    run_id = request.session.get("active_run")
    if not run_id:
        messages.error(request, "Upload and process a dataset before making a prediction.")
        from django.shortcuts import redirect
        return redirect("index")
    model_path = os.path.join(settings.MEDIA_ROOT, "runs", run_id, "churn_model.joblib")
    try:
        result = predict_one(model_path, request.POST)
        return render(request, "predictor/result.html", {"result": result})
    except Exception as exc:
        messages.error(request, f"Prediction failed: {exc}")
        from django.shortcuts import redirect
        return redirect("index")
