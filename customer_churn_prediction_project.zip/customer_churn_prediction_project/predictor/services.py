import os, json, joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, classification_report
from sklearn.feature_selection import SelectFromModel

TARGET_CANDIDATES = ["Churn", "churn", "Exited", "Attrition", "target", "Target"]
DROP_CANDIDATES = ["customerID", "CustomerID", "customer_id", "RowNumber", "Surname"]

def load_frame(uploaded_file):
    name = uploaded_file.name.lower()
    if name.endswith(".csv"):
        return pd.read_csv(uploaded_file)
    if name.endswith(".xlsx") or name.endswith(".xls"):
        return pd.read_excel(uploaded_file)
    raise ValueError("Please upload a CSV or Excel (.xlsx/.xls) file.")

def clean_frame(raw):
    df = raw.copy()
    df.columns = [str(c).strip() for c in df.columns]
    df = df.drop_duplicates()
    # Common Telco dataset quirk: blank TotalCharges values should be numeric missing values.
    if "TotalCharges" in df.columns:
        df["TotalCharges"] = pd.to_numeric(df["TotalCharges"].replace(r"^\s*$", np.nan, regex=True), errors="coerce")
    for col in df.select_dtypes(include="object").columns:
        df[col] = df[col].map(lambda x: x.strip() if isinstance(x, str) else x)
        df[col] = df[col].replace("", np.nan)
    target = next((c for c in TARGET_CANDIDATES if c in df.columns), None)
    if target is None:
        raise ValueError("Target column not found. Expected a column named Churn (recommended), Exited, Attrition, or target.")
    df = df.dropna(subset=[target])
    for col in DROP_CANDIDATES:
        if col in df.columns:
            df = df.drop(columns=[col])
    return df, target

def _cap_outliers(train, other, numeric_cols):
    train = train.copy()
    other = other.copy()
    bounds = {}
    for col in numeric_cols:
        q1, q3 = train[col].quantile([0.25, 0.75])
        iqr = q3 - q1
        low, high = q1 - 1.5 * iqr, q3 + 1.5 * iqr
        bounds[col] = [float(low), float(high)]
        train[col] = train[col].clip(low, high)
        other[col] = other[col].clip(low, high)
    return train, other, bounds

def make_eda(df, target, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    numeric = df.select_dtypes(include=np.number).columns.tolist()
    categorical = df.select_dtypes(exclude=np.number).columns.tolist()
    sns.set_theme(style="whitegrid")
    # Target distribution
    plt.figure(figsize=(6,4))
    sns.countplot(data=df, x=target)
    plt.title("Customer Churn Distribution")
    plt.tight_layout(); plt.savefig(os.path.join(out_dir, "churn_distribution.png")); plt.close()
    # Numeric distributions
    if numeric:
        col = numeric[0]
        plt.figure(figsize=(6,4)); sns.histplot(df[col].dropna(), kde=True)
        plt.title(f"Distribution: {col}"); plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "numeric_distribution.png")); plt.close()
        plt.figure(figsize=(6,4)); sns.boxplot(x=df[col])
        plt.title(f"Outlier check: {col}"); plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "boxplot.png")); plt.close()
    # Scatter plot
    if len(numeric) >= 2:
        plt.figure(figsize=(6,4))
        sns.scatterplot(data=df, x=numeric[0], y=numeric[1], hue=target, alpha=.65)
        plt.title(f"{numeric[0]} vs {numeric[1]}"); plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "scatterplot.png")); plt.close()
    # Correlation heatmap
    if len(numeric) >= 2:
        plt.figure(figsize=(8,6))
        sns.heatmap(df[numeric].corr(), annot=True, cmap="coolwarm", fmt=".2f")
        plt.title("Numeric Feature Correlation"); plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "correlation_heatmap.png")); plt.close()
    # Top categorical churn-rate chart
    if categorical:
        c = categorical[0]
        try:
            rates = df.groupby(c, dropna=False)[target].apply(
                lambda s: (s.astype(str).str.lower().isin(["yes","1","true","churned","exited"])).mean()
            ).sort_values(ascending=False).head(10)
            plt.figure(figsize=(7,4)); rates.plot(kind="bar")
            plt.ylabel("Positive class proportion"); plt.title(f"Positive outcome by {c}")
            plt.tight_layout(); plt.savefig(os.path.join(out_dir, "category_churn.png")); plt.close()
        except Exception:
            pass

def train_pipeline(df, target, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    X = df.drop(columns=[target]).copy()
    y_raw = df[target].astype(str).str.strip()
    classes = sorted(y_raw.unique().tolist())
    if len(classes) != 2:
        raise ValueError(f"This project expects a binary churn target; found {len(classes)} classes: {classes}")
    positive_candidates = {"yes", "1", "true", "churn", "churned", "exited"}
    positive = next((c for c in classes if c.lower() in positive_candidates), classes[-1])
    y = (y_raw == positive).astype(int)
    numeric_cols = X.select_dtypes(include=np.number).columns.tolist()
    categorical_cols = X.select_dtypes(exclude=np.number).columns.tolist()
    # Split before learning outlier limits to avoid test-set leakage.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )
    X_train, X_test, outlier_bounds = _cap_outliers(X_train, X_test, numeric_cols)
    numeric_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("scaler", StandardScaler()),
    ])
    categorical_pipe = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("encoder", OneHotEncoder(handle_unknown="ignore")),
    ])
    transformers = []
    if numeric_cols: transformers.append(("num", numeric_pipe, numeric_cols))
    if categorical_cols: transformers.append(("cat", categorical_pipe, categorical_cols))
    preprocessor = ColumnTransformer(transformers=transformers, remainder="drop")
    model = RandomForestClassifier(
        n_estimators=300, random_state=42, class_weight="balanced",
        min_samples_split=4, n_jobs=-1
    )
    pipe = Pipeline([("preprocess", preprocessor), ("model", model)])
    pipe.fit(X_train, y_train)
    pred = pipe.predict(X_test)
    metrics = {
        "accuracy": round(float(accuracy_score(y_test, pred)), 4),
        "precision": round(float(precision_score(y_test, pred, zero_division=0)), 4),
        "recall": round(float(recall_score(y_test, pred, zero_division=0)), 4),
        "f1": round(float(f1_score(y_test, pred, zero_division=0)), 4),
        "positive_class": positive,
        "negative_class": next(c for c in classes if c != positive),
        "rows_used": int(len(df)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "numeric_features": numeric_cols,
        "categorical_features": categorical_cols,
        "outlier_bounds": outlier_bounds,
        "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
    }
    # Feature importance after encoding, retained for feature-selection evidence.
    try:
        names = pipe.named_steps["preprocess"].get_feature_names_out()
        importances = pipe.named_steps["model"].feature_importances_
        top = sorted(zip(names.tolist(), importances.tolist()), key=lambda x:x[1], reverse=True)[:15]
        metrics["top_features"] = [{"feature": str(a), "importance": round(float(b), 5)} for a,b in top]
        plt.figure(figsize=(8,5))
        pd.DataFrame(top, columns=["Feature","Importance"]).sort_values("Importance").plot(
            kind="barh", x="Feature", y="Importance", legend=False, figsize=(8,5)
        )
        plt.title("Top Feature Importances"); plt.tight_layout()
        plt.savefig(os.path.join(out_dir, "feature_importance.png")); plt.close()
    except Exception:
        metrics["top_features"] = []
    joblib.dump({"pipeline": pipe, "feature_columns": X.columns.tolist(),
                 "target": target, "metrics": metrics, "positive": positive,
                 "negative": next(c for c in classes if c != positive),
                 "numeric_cols": numeric_cols, "categorical_cols": categorical_cols,
                 "outlier_bounds": outlier_bounds},
                os.path.join(out_dir, "churn_model.joblib"))
    return metrics

def run_analysis(df, out_dir):
    cleaned, target = clean_frame(df)
    if len(cleaned) < 100:
        raise ValueError("Please upload at least 100 usable rows. The assignment requires a dataset with 500+ records.")
    make_eda(cleaned, target, out_dir)
    metrics = train_pipeline(cleaned, target, out_dir)
    missing = cleaned.isna().sum().to_dict()
    summary = {
        "rows": int(cleaned.shape[0]), "columns": int(cleaned.shape[1]),
        "duplicates_removed": int(df.shape[0] - cleaned.shape[0] - int(df[target].isna().sum()) if target in df.columns else 0),
        "missing": {str(k): int(v) for k,v in missing.items()},
        "numeric_columns": cleaned.select_dtypes(include=np.number).columns.tolist(),
        "categorical_columns": cleaned.select_dtypes(exclude=np.number).columns.tolist(),
        "target": target,
    }
    cleaned.head(10).to_csv(os.path.join(out_dir, "preview.csv"), index=False)
    with open(os.path.join(out_dir, "summary.json"), "w") as f: json.dump(summary, f, indent=2)
    with open(os.path.join(out_dir, "metrics.json"), "w") as f: json.dump(metrics, f, indent=2)
    return cleaned, summary, metrics

def predict_one(model_path, values):
    bundle = joblib.load(model_path)
    pipe = bundle["pipeline"]
    row = {}
    for col in bundle["feature_columns"]:
        value = values.get(col, "")
        if col in bundle["numeric_cols"]:
            row[col] = pd.to_numeric(value, errors="coerce")
        else:
            row[col] = str(value) if value is not None else np.nan
    frame = pd.DataFrame([row], columns=bundle["feature_columns"])
    pred = int(pipe.predict(frame)[0])
    probability = float(pipe.predict_proba(frame)[0][1])
    return {
        "prediction": bundle["positive"] if pred == 1 else bundle["negative"],
        "probability": round(probability * 100, 2),
        "positive": bundle["positive"],
    }
