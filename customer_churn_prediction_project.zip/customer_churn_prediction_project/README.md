# Customer Churn Prediction — Data Mining + Django

This project implements both assignment parts in one Django application.

## Dataset
Recommended: **IBM Telco Customer Churn** from Kaggle:
https://www.kaggle.com/datasets/blastchar/telco-customer-churn

It contains 7,043 customer records and 21 columns, including numerical and categorical attributes. The target is `Churn` (Yes/No). You can also download the CSV from IBM's public repository:
https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv

## Part 1 — Data Mining & ML Pipeline
- Cleans column names and whitespace, converts `TotalCharges` to numeric, removes duplicates and customer ID fields.
- Identifies missing values; numeric values are median-imputed and categorical values are mode-imputed inside the model pipeline.
- Detects and caps numeric outliers with IQR bounds learned from training data only.
- Applies StandardScaler to numeric features and OneHotEncoder to categorical features.
- Uses Random Forest feature importance as feature-selection/importance analysis.
- Generates target distribution, numeric distribution, box plot, scatter plot, correlation heatmap, categorical outcome plot and feature-importance chart.
- Uses stratified train/test split and reports accuracy, precision, recall, F1-score and confusion matrix.

## Part 2 — Django Application
- CSV/XLSX upload.
- Dataset dimensions, missing-value counts and first 10 rows.
- Dynamic charts created from the uploaded data.
- Model performance metrics.
- Prediction form generated from the uploaded dataset's feature columns.

## Download the dataset (optional)
Run this once from the project folder to download the public IBM CSV into `data/`:

```bash
python download_dataset.py
```

You can alternatively download it from Kaggle using the link above and upload the CSV through the website.

## Run on macOS
Open Terminal and enter these commands from the project folder:

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Open http://127.0.0.1:8000/

## Dataset format
- Upload the Kaggle CSV `WA_Fn-UseC_-Telco-Customer-Churn.csv`.
- The target must be a binary column named `Churn` (or `churn`, `Exited`, `Attrition`, `target`, `Target`).
- The uploaded file should contain at least 500 records for the assignment. The app currently enforces at least 100 usable records so it can also be tested with smaller sample files.

## Important academic notes
- The supplied Telco dataset is a cross-sectional benchmark. The model classifies churn labels in a held-out test set; it is not a time-series forecast.
- Random Forest probabilities are estimates, not certainty.
- Review the dataset's source and terms before reuse. Cite Kaggle/IBM in your project report.
- This is an educational local-development project. Before deployment, configure a secure `SECRET_KEY`, set `DEBUG=False`, validate uploads more strictly, and add authentication/storage controls.
