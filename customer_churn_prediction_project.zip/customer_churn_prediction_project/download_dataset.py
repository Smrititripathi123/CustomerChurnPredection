"""Download the public IBM Telco Customer Churn CSV into data/."""
from pathlib import Path
from urllib.request import urlretrieve

URL = "https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv"
destination = Path(__file__).resolve().parent / "data" / "Telco-Customer-Churn.csv"
destination.parent.mkdir(parents=True, exist_ok=True)
print("Downloading IBM Telco Customer Churn dataset...")
urlretrieve(URL, destination)
print(f"Saved: {destination}")
